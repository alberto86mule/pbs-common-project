package org.mhra.mule;

public enum IntegrationPatternType {
	HTTP,
	BATCH, 
	MESSAGING,
	FILE,
	SFTP
}
