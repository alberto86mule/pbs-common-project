package org.mhra.mule;

public enum TransactionStatusType {
	IN_PROGRESS,
	SUCCESS,
	FAILURE,
	ABORTED
}
