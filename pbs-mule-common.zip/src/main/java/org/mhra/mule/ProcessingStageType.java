package org.mhra.mule;

public enum ProcessingStageType {
	IN_PROGRESS,
	COMPLTED
}
